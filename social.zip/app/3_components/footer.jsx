export default function Footer() {
  return (
    <footer>
      <h1>Kde nás najdete</h1>
      <img
        src=""
        alt="Mapa"
      />
      <p>Krakonošovo náměstí 1</p>
    </footer>
  );
}
