export default function Header2() {
  return (
    <header>
      <h1>Cukrárna</h1>
    </header>
  );
}
