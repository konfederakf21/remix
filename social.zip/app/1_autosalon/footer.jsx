export default function Footer() {
  return (
    <footer>
      <h1>Filip Konfederák</h1>
    </footer>
  );
}
