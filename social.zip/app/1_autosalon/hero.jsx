export default function Hero() {
  return (
    <section>
      <h1>Lorem ipsum dolor sit amet.</h1>
      <img
        src="https://cdn.pixabay.com/photo/2020/02/03/10/02/sports-car-4815234_640.jpg"
        alt="Auto"
      />
    </section>
  );
}
