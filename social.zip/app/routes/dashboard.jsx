export default function Dashboard() {
  return (
    <main
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "100vh",
        flexDirection: "column",
      }}>
      <h1>Vítej na Dashboardu!</h1>
      <p>Jsi úspěšně přihlášen.</p>
    </main>
  );
}
