/*import { sql } from "./sql";

export async function getHotels() {
  const response = await sql(`SELECT * FROM hotel_world`);
  console.log(response);

  let hotelList = response;
  return hotelList;
}
*/
