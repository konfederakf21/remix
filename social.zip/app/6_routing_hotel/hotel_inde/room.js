/*import { sql } from "./sql";

export async function getRoomData(roomId) {
  const response = await sql(`SELECT * FROM Hotel WHERE id=${roomId}`);
  console.log(response);

  let roomData = response;
  return roomData;
}
*/
