/*import { Link } from "@remix-run/react";

export default function RoomsPage() {
  return (
    <>
      <h1>Rooms</h1>
      <h1>
        <Link to="/detail/1">Single</Link>
      </h1>
      <h1>Double</h1>
      <h1>King</h1>
    </>
  );
}
*/
