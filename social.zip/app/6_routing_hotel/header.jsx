/*import style from "../6_routing_hotel/header.module.css";
import { Link } from "@remix-run/react";

export default function Header() {
  return (
    <header>
      <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/rooms">Rooms</Link>
          </li>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
        </ul>
        <ul>
          <li>
            <Link to="/book">Book now</Link>
          </li>
        </ul>
      </nav>
    </header>
  );
}

/*<li>
<Link to="/">
  <img
    src="https://cdn.pixabay.com/photo/2020/05/09/09/13/house-5148865_640.jpg"
    alt="Hotel"
  />
</Link>
</li>
*/
